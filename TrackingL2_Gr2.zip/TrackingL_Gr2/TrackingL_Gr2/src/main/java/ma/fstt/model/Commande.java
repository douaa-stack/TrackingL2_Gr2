package ma.fstt.model;


// java bean
public class Commande extends Livreur {
    private Long numclt ;
    private Long numcommande ;
    private String nom ;

    private String prenom ;
    private String Adresse;
    private int datecommande ;
    private int totalcommande ;


    public Commande(long aLong, long resultSetLong, String string, String resultSetString, String setString, int anInt, int resultSetInt) {
    }

    public Commande(Long numcommande , String nom , String prenom, String Adresse, String datecommande, String totalcommande ) {
        this.numcommande = numcommande;
        this.nom = nom;
        this.prenom= prenom;
        this.Adresse=Adresse;
        this.datecommande= Integer.parseInt(datecommande);
        this.totalcommande= Integer.parseInt(totalcommande);


    }



    public int getTotalcommande() {
        return totalcommande;
    }

    public Long getNumclt() {
        return numclt;
    }

    public Long getNumcommande() {
        return numcommande;
    }

    public String getAdresse() {
        return Adresse;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setAdresse(String adresse) {
        Adresse = adresse;
    }

    public void setDatecommande(int datecommande) {
        this.datecommande = datecommande;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setNumclt(Long numclt) {
        this.numclt = numclt;
    }

    public void setNumcommande(Long numcommande) {
        this.numcommande = numcommande;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setTotalcommande(int totalcommande) {
        this.totalcommande = totalcommande;
    }

    public int getDatecommande() {
        return datecommande;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "numclt=" + numclt +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom+ '\'' +
                "Adresse=" + Adresse +
                ", datecommande='" + datecommande + '\'' +
                ", totalcommande='" + totalcommande+ '\'' +'}';
    }
}

