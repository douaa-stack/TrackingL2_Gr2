package ma.fstt.trackingl;

import javafx.stage.Stage;

import java.io.IOException;

public class MenuController {
    public void openLivreurs(){
        HelloApplication app = new HelloApplication();
        Stage stage = new Stage();
        try{
            app.start(stage);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void openProduits(){
        ProduitApplication app = new ProduitApplication();
        Stage stage = new Stage();
        try{
            app.start(stage);
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
