package ma.fstt.model;


// java bean
public class Produit {
    private Long id_produit ;

    private String reference ;

    private String designation ;

    public Produit() {
    }

    public Produit(Long id_produit, String reference, String designation) {
        this.id_produit = id_produit;
        this.reference = reference;
        this.designation = designation;
    }

    public Long getId_produit() {
        return id_produit;
    }

    public void setId_produit(Long id_produit) {
        this.id_produit = id_produit;
    }

    public String getReference() {
        return reference;
    }

    public void setNom(String reference) {
        this.reference = reference;
    }

    public String getDesignation() {
        return designation;
    }

    public void setTelephone(String designation) {
        this.designation = designation;
    }

    @Override
    public String toString() {
        return "Produit{" +
                "id_produit=" + id_produit +
                ", reference='" + reference + '\'' +
                ", designation='" + designation + '\'' +
                '}';
    }
}
