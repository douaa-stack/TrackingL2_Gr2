package ma.fstt.model;



import com.sun.javafx.charts.Legend;
import javafx.fxml.FXML;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LivreurDAO extends BaseDAO<Livreur>{
  

    public LivreurDAO() throws SQLException {

        super();
    }

    @Override
    public void save(Livreur object) throws SQLException {

        String request = "insert into livreur (nom , telephone) values (? , ?)";

        // mapping objet table

        this.preparedStatement = this.connection.prepareStatement(request);
        // mapping
        this.preparedStatement.setString(1 , object.getNom());

        this.preparedStatement.setString(2 , object.getTelephone());


        this.preparedStatement.execute();
    }


    @Override
    public void update(Livreur object) throws SQLException {


        String newNom = "";
        String newtele = "";
        // la nouvelle valeur pour le champ "nom"
        String query="UPDATE livreur SET nom ='" + newNom +"telephone " +newtele+ "'";

        // mapping objet table

        this.preparedStatement = this.connection.prepareStatement(query);
        // mapping
        this.preparedStatement.setString(1 , object.getNom());

        this.preparedStatement.setString(2 , object.getTelephone());


        this.preparedStatement.execute();
    }

    @Override

        public void delete(Livreur object) throws SQLException {

        }


    @Override
    public List<Livreur> getAll()  throws SQLException {

        List<Livreur> mylist = new ArrayList<Livreur>();

        String request = "select * from livreur ";

        this.statement = this.connection.createStatement();

        this.resultSet =   this.statement.executeQuery(request);

// parcours de la table
        while ( this.resultSet.next()){

// mapping table objet
            mylist.add(new Livreur(this.resultSet.getLong(1) ,
                    this.resultSet.getString(2) , this.resultSet.getString(3)));


        }


        return mylist;
    }

    @Override
    public Livreur getOne(Long id) throws SQLException {
        Livreur livreur = null;

        String request = "SELECT * FROM livreur WHERE id_livreur=" + id;

        this.statement = this.connection.createStatement();

        this.resultSet = this.statement.executeQuery(request);

        if (this.resultSet.next()) {
            livreur = new Livreur(
                    this.resultSet.getLong(1),
                    this.resultSet.getString(2),
                    this.resultSet.getString(3)
            );
        }

        return livreur;
    }

}
