package ma.fstt.model;



import com.sun.javafx.charts.Legend;
import javafx.fxml.FXML;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommandeDAO extends BaseDAO<Commande>{


    public CommandeDAO() throws SQLException {

        super();
    }

    @Override
    public void save(Commande object) throws SQLException {

        String request = "insert into Commande  ( numcommande ,  nom ,  prenom, Adresse,datecommande, totalcommande) values (? , ?,? , ?,? , ?)";

        // mapping objet table

        this.preparedStatement = this.connection.prepareStatement(request);
        // mapping
        this.preparedStatement.setString(1 , object.getNom());

        this.preparedStatement.setString(2 , object.getPrenom());
        this.preparedStatement.setString(3 , object.getAdresse());
        this.preparedStatement.setString(4, String.valueOf(object.getDatecommande()));
        this.preparedStatement.setString(5, String.valueOf(object.getNumcommande()));
        this.preparedStatement.execute();
    }

    @Override
    public void update(Commande object) throws SQLException {

    }


    @Override

    public void delete(Commande object) throws SQLException {

    }


    @Override
    public List<Commande> getAll()  throws SQLException {

        List<Commande> mylist = new ArrayList<Commande>();

        String request = "select * from Commande ";

        this.statement = this.connection.createStatement();

        this.resultSet =   this.statement.executeQuery(request);

// parcours de la table
        while ( this.resultSet.next()){

// mapping table objet
            mylist.add(new Commande(this.resultSet.getLong(1) ,
                    this.resultSet.getLong(2) , this.resultSet.getString(3),
                    this.resultSet.getString(4) , this.resultSet.getString(5), this.resultSet.getInt(6),
                    this.resultSet.getInt(7)));


        }


        return mylist;
    }

    @Override
    public Commande getOne(Long numclt) throws SQLException {
        Commande commande = null;

        String request = "SELECT * FROM Commande WHERE numcommande=" + numclt;

        this.statement = this.connection.createStatement();

        this.resultSet = this.statement.executeQuery(request);

        if (this.resultSet.next()) {
         commande =
                 new Commande(this.resultSet.getLong(1) ,
                         this.resultSet.getLong(2) , this.resultSet.getString(3),
                         this.resultSet.getString(4) , this.resultSet.getString(5), this.resultSet.getInt(6),
                         this.resultSet.getInt(7));

        }

        return commande;
    }

}
