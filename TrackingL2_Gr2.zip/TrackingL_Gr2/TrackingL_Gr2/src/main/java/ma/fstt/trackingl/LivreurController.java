package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import ma.fstt.model.Livreur;
import ma.fstt.model.LivreurDAO;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LivreurController implements Initializable {
    @FXML
    private Label lblId ;
    @FXML
    private Label lblNom ;
    @FXML
    private Label lblTelephone ;

    public Livreur getLivreur(long id) {
        LivreurDAO livreurDAO = null;
        Livreur livreur = null;

        try {
            livreurDAO = new LivreurDAO();
            livreur = livreurDAO.getOne(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        System.out.println(livreur.getNom());
        return livreur;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Livreur livreur = new Livreur();

        livreur = getLivreur(Long.valueOf(lblId.getText()));
        lblNom.setText(livreur.getNom());
        lblTelephone.setText(livreur.getTelephone());
    }
}
