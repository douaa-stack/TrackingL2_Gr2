package ma.fstt.trackingl  ;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class CommandeApplication extends Application {
    private Long numclt ;
    private Long numcommande ;
    private String nom ;

    private String prenom ;
    private String Adresse;
    private int datecommande ;
    private int totalcommande ;
    public int getTotalcommande() {
        return totalcommande;
    }

    public Long getNumclt() {
        return numclt;
    }

    public Long getNumcommande() {
        return numcommande;
    }

    public String getAdresse() {
        return Adresse;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setAdresse(String adresse) {
        Adresse = adresse;
    }

    public void setDatecommande(int datecommande) {
        this.datecommande = datecommande;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setNumclt(Long numclt) {
        this.numclt = numclt;
    }

    public void setNumcommande(Long numcommande) {
        this.numcommande = numcommande;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setTotalcommande(int totalcommande) {
        this.totalcommande = totalcommande;
    }

    public int getDatecommande() {
        return datecommande;
    }


    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(CommandeApplication.class.getResource("commande-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 500);
        stage.setTitle("Commande!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}