package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;


import javafx.stage.Stage;
import ma.fstt.model.Commande;
import ma.fstt.model.CommandeDAO;
import ma.fstt.model.Produit;
import ma.fstt.model.ProduitDAO;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CommandeController implements Initializable {
    @FXML
    private TextField lbnumclt;

    @FXML
    private TextField getLbnumcommande;
    ;

    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private TextField nom;
    @FXML
    private TextField prenom;
    @FXML
    private TextField Adresse;
    @FXML
    private TextField datecommande;
    @FXML
    private TextField totalcommande;
    @FXML
    private TableView<Commande> mytable;


    @FXML
    private TableColumn<Commande, Long> col_numclt;
    @FXML
    private TableColumn<Commande, Long> col_numcommande;
    @FXML
    private TableColumn<Commande, String> col_nom;

    @FXML
    private TableColumn<Commande, String> col_prenom;
    @FXML
    private TableColumn<Commande, String> col_Adresse;
    @FXML
    private TableColumn<Commande, String> col_datecommande;
    @FXML
    private TableColumn<Commande, String> col_totalcommande;


    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
          CommandeDAO commandeDAO = new CommandeDAO();

          Commande commande = new Commande(0l , nom.getText(), prenom.getText()
                  , Adresse.getText(), datecommande.getText(), totalcommande.getText()
          );

           commandeDAO.save(commande);


            UpdateTable();

            nom.setText("");
            prenom.setText("");
            Adresse.setText("");
            datecommande.setText("");
            totalcommande.setText("");


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }





    public void UpdateTable(){
        col_numclt.setCellValueFactory(new PropertyValueFactory<Commande,Long>("numclt"));
        col_numcommande.setCellValueFactory(new PropertyValueFactory<Commande,Long>("numcommande"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Commande,String>("nom"));
        col_prenom.setCellValueFactory(new PropertyValueFactory<Commande,String>("prenom"));
        col_Adresse.setCellValueFactory(new PropertyValueFactory<Commande,String>("Adresse"));
        col_datecommande.setCellValueFactory(new PropertyValueFactory<Commande,String>("datecommande"));
        col_totalcommande.setCellValueFactory(new PropertyValueFactory<Commande,String>("totalcommande"));

        mytable.setItems(this.getDataCommande());
    }

    public static ObservableList<Commande> getDataCommande(){

        CommandeDAO commandeDAO = null;

        ObservableList<Commande> listfx = FXCollections.observableArrayList();

        try {
            CommandeDAO CommandeDAO = new CommandeDAO();
            for (Commande ettemp : CommandeDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    public void openLivreur(){
     CommandeApplication app = new CommandeApplication();
        app.setNumclt(Long.valueOf(lbnumclt.getText()));
        Stage stage = new Stage();
        try{
            app.start(stage);
        }catch(IOException e){
            e.printStackTrace();
        }
    }


    public void afficheLivreur(){
        mytable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                // Mettre à jour les champs de texte avec les valeurs de la ligne sélectionnée
                lbnumclt.setText(String.valueOf(newSelection.getNumclt()));
                nom.setText(newSelection.getNom());
                prenom.setText(newSelection.getPrenom());
                Adresse.setText(newSelection.getAdresse());
                datecommande.setText(String.valueOf(newSelection.getDatecommande()));
                totalcommande.setText(String.valueOf(newSelection.getTotalcommande()));
            }
        });
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
}