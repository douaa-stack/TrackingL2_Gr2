package ma.fstt.trackingl  ;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.fstt.model.Livreur;
import ma.fstt.model.LivreurDAO;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;


public class HelloController implements Initializable {

    @FXML
    private Label lblId ;

    @FXML
    private TextField nom ;
    @FXML
    private Button btnLivreur ;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private TextField tele ;


    @FXML
    private TableView<Livreur> mytable ;


    @FXML
    private TableColumn<Livreur ,Long> col_id ;

    @FXML
    private TableColumn <Livreur ,String> col_nom ;

    @FXML
    private TableColumn <Livreur ,String> col_tele ;


    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
            LivreurDAO livreurDAO = new LivreurDAO();

            Livreur liv = new Livreur(0l , nom.getText() , tele.getText());

            livreurDAO.save(liv);

            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void update() {
        String query = "UPDATE  livreur SET nom  = '" + this.nom.getText() + "" +
                "" + this.tele.getText() + "'  WHERE id = " + this.lblId.getText() + "";
        this.executeQuery(query);

    }
    @FXML
    protected void handleButtonAction(ActionEvent event) {
        if (event.getSource() == this.btnUpdate) {
            this.update();
            this.showBooks();


        }

    }
    private void deleteButton() {
        String query = "DELETE FROM livreur WHERE id =" + this.lblId.getText() + "";
        this.executeQuery(query);
        this.showBooks();
    }
    public void showBooks() {
        ObservableList<Livreur> list = this.getDataLivreurs();
        this.col_id.setCellValueFactory(new PropertyValueFactory("id_livreur"));
        this.col_nom.setCellValueFactory(new PropertyValueFactory("nom"));
        this.col_tele.setCellValueFactory(new PropertyValueFactory("telephone"));
        this.mytable.setItems(list);
    }
    public void executeQuery(String query) {
        Connection conn = this.getConnection();

        try {
            Statement st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception var5) {
            var5.printStackTrace();
        }

    }

    public Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/glovo", "root", "");
            return conn;
        } catch (Exception var3) {
            System.out.println("Error: " + var3.getMessage());
            return null;
        }
    }


    public void openLivreur(){
        LivreurApplication app = new LivreurApplication();
        app.setId_livreur(Long.valueOf(lblId.getText()));
        Stage stage = new Stage();
        try{
            app.start(stage);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void afficheLivreur(){
        mytable.getSelectionModel().selectedItemProperty().addListener((obs,
                                                                        oldSelection, newSelection) -> {
            if (newSelection != null) {
                // Mettre à jour les champs de texte avec les valeurs de la ligne sélectionnée
                lblId.setText(String.valueOf(newSelection.getId_livreur()));
                nom.setText(newSelection.getNom());
                tele.setText(newSelection.getTelephone());
            }
        });
    }

    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Livreur,Long>("id_livreur"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Livreur,String>("nom"));

        col_tele.setCellValueFactory(new PropertyValueFactory<Livreur,String>("telephone"));



        mytable.setItems(this.getDataLivreurs());
    }

    public static ObservableList<Livreur> getDataLivreurs(){

        LivreurDAO livreurDAO = null;

        ObservableList<Livreur> listfx = FXCollections.observableArrayList();

        try {
            livreurDAO = new LivreurDAO();
            for (Livreur ettemp : livreurDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

}
}